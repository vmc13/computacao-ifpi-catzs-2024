/*
  ********************************************
  *        Victória Mendes da Costa          *
  *        Lic. em Computação - IFPI         *
  *        Estrutura de Dados - 2024.2       *
  ********************************************
*/

#include <stdio.h>

void exibir_menu() {
    printf("Menu do Programa:\n");
    printf("1 – Cadastrar Produto\n");
    printf("2 – Listar todos os Produtos\n");
    printf("3 – Consultar informações sobre produto\n");
    printf("4 – Excluir Produto\n");
}

int main() {
    exibir_menu();

    return 0;
}

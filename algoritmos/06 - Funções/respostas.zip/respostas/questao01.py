def sucessor(num):
    suc = num+1
    return suc

value = int(input("Digite um número: "))
print(f"O sucessor de {value} é {sucessor(value)}")
def exibir_menu():
    print("1 – Cadastrar Produto")
    print("2 – Listar todos os Produtos")
    print("3 – Consultar informações sobre produto")
    print("4 – Excluir Produto")

exibir_menu()

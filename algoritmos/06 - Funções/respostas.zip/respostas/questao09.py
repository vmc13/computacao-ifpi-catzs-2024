def exibir_em_real(valor):
    print(f"R$ {valor:.2f}")

exibir_em_real(10.50)
exibir_em_real(1234.567)

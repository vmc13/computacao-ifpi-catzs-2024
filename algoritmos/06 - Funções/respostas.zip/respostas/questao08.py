def verificar_paridade(numero):
    if numero % 2 == 0:
        print(f"O número {numero} é par.")
    else:
        print(f"O número {numero} é ímpar.")

verificar_paridade(7)
verificar_paridade(12)

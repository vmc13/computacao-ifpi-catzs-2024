meses = ["Jan", "Fev", "Mar", "Abr", "Mai", "Jun", "Jul", "Ago", "Set", "Out", "Nov", "Dez"]

entrada = int(input("Insira o número do mês: "))
print(meses[entrada-1])
lista = [5, 12, 7, 18, 23, 9, 31, 14, 6, 20]
multi = 0

for i in lista:
    multi *= i

print(i)
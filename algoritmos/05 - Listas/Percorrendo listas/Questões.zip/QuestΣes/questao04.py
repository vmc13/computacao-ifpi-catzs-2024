nomes = ["Alice", "Bob", "Carlos", "Diana", "Eva"]
notas = [8.5, 9.0, 7.5, 6.0, 9.3]

for i in range(5):
    print(f"{nomes[i]}: {notas[i]}")

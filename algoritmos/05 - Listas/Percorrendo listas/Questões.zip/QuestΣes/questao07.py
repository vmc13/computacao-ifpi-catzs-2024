lista = [15, -8, 22, 0, -4, 11, 7, -17, 30,
-5]
soma = 0

for i in lista:
    soma += i

print(soma)
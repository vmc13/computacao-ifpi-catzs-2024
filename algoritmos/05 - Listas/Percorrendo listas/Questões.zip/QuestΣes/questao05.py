lista01 = [11, 12, 13, 14]
lista02 = [21, 22, 23, 24]
lista03 = []

for i in lista01:
    lista03.append(i)

for i in lista02:
    lista03.append(i)

print(lista03)
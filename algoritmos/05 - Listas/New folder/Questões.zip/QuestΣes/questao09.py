import math

numeros = [5, 12, 7, 18, 23, 9, 31, 14, 6, 20]

multiplicacao_total = math.prod(numeros)

print(f"A multiplicação de todos os elementos da lista é: {multiplicacao_total}")

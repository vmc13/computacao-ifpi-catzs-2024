numeros = [15, -8, 22, 0, -4, 11, 7, -17, 30, -5]

soma_total = sum(numeros)

print(f"A soma de todos os elementos da lista é: {soma_total}")

numeros = [7, -3, 15, 0, -22, 9, -6, 13, -8, 4]

#a
for i in numeros:
    print(i)

#b
for i in numeros:
    if i>0:
        print(i)

#c
for i in numeros:
    if i<0:
        print(i)

#d
for i in numeros:
    if i%2==0:
        print(i)

#e
for i in numeros:
    if i%2!=0:
        print(i)

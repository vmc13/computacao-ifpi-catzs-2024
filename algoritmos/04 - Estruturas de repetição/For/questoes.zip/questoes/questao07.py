for i in range(1, 12):
    print(i)
    
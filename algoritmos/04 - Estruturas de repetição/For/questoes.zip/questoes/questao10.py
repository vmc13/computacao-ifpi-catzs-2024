for i in range(1, 11):
    print(f'5 X {i} = {5*i}')
soma = 0
for i in range(1, 6):
    print(i)
    soma+=i

print(f"Soma = {soma}")
soma = 0

for i in range(1, 6):
    numero = int(input(f"Insira o {i}º valor: "))
    soma+=numero

print(f'Soma = {soma}')
numero = int(input('Insira um número inteiro maior que 1: '))

for i in range(1, numero+1):
    print(i)
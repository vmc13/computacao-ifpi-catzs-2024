for i in range(50, 101):
    print(i)